function Write-SetupReport {
    param($Config)

    $results = Invoke-ComponentVerification -Config $Config
    $okCount = @($results | Where-Object { $_.Status -eq 'OK' }).Count
    $total = $results.Count
    $failCount = $total - $okCount
    $timestamp = Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'
    $reportPath = Join-Path $script:SetupDataDir "setup-report-$timestamp.md"
    $state = Get-SetupState

    $baseUrlDisplay = if ($Config) { $Config.BaseUrl } else { '(not configured)' }

    $lines = @(
        '# Dev Environment Setup Report',
        '',
        "Generated: $timestamp",
        '',
        "| Component | Status | Version/Detail | Action Required |",
        "|-----------|--------|----------------|-----------------|"
    )

    foreach ($r in $results) {
        $detail = if ($r.Detail) { $r.Detail -replace '\|', '/' } else { '-' }
        $action = if ($r.Action) { $r.Action -replace '\|', '/' } else { '-' }
        $lines += "| $($r.Name) | $($r.Status) | $detail | $action |"
    }

    $lines += @(
        '',
        "## Summary: $okCount/$total complete, $failCount remaining",
        '',
        '### Configuration',
        "- Artifactory base: $baseUrlDisplay",
        "- State file: $script:StatePath",
        "- Log file: $script:LogPath",
        ''
    )

    if ($state.steps) {
        $lines += '### Step History'
        $lines += ''
        $lines += '| Step | Name | Status | Attempts |'
        $lines += '|------|------|--------|----------|'
        foreach ($prop in $state.steps.PSObject.Properties) {
            $s = $prop.Value
            $lines += "| $($prop.Name) | $($s.name) | $($s.status) | $($s.attempts) |"
        }
        $lines += ''
    }

    if ($failCount -gt 0) {
        $lines += '### Recommended Next Steps'
        $lines += ''
        foreach ($r in ($results | Where-Object { $_.Status -ne 'OK' })) {
            $lines += "- **$($r.Name)**: $($r.Action)"
        }
        $lines += ''
        $lines += 'Re-run with: `.\Setup-DevEnvironment.ps1 -Resume`'
    }
    else {
        $lines += 'All components verified successfully.'
    }

    $content = $lines -join "`n"
    Set-Content -Path $reportPath -Value $content -Encoding UTF8

    Write-Host ''
    Write-Host '  ============================================================' -ForegroundColor Cyan
    Write-Host '  SETUP REPORT' -ForegroundColor Cyan
    Write-Host '  ============================================================' -ForegroundColor Cyan
    Write-Host ''

    foreach ($r in $results) {
        $color = if ($r.Status -eq 'OK') { 'Green' } else { 'Red' }
        $icon = if ($r.Status -eq 'OK') { '[OK]' } else { '[FAIL]' }
        Write-Host "  $icon $($r.Name): $($r.Status)" -ForegroundColor $color
        if ($r.Action -and $r.Status -ne 'OK') {
            Write-Host "      >> $($r.Action)" -ForegroundColor DarkYellow
        }
    }

    Write-Host ''
    Write-Host "  Summary: $okCount/$total complete, $failCount remaining" -ForegroundColor $(if ($failCount -eq 0) { 'Green' } else { 'Yellow' })
    Write-Host "  Report saved: $reportPath" -ForegroundColor White
    Write-Host "  Log file:     $script:LogPath" -ForegroundColor DarkGray
    Write-Host ''

    Write-SetupLog "Report generated: $reportPath ($okCount/$total OK)"
    return ($failCount -eq 0)
}