function Invoke-SetupStep {
    param(
        [int]$StepNumber,
        [int]$TotalSteps,
        [string]$Name,
        [string]$Title,
        [scriptblock]$Action,
        [scriptblock]$Verify,
        [string]$FailureHint = 'Check setup.log for details and retry this step.',
        [int]$MaxRetries = 3,
        [switch]$SkipIfCompleted,
        [switch]$Force
    )

    if ($SkipIfCompleted -and -not $Force) {
        if (Test-StepCompleted -StepNumber $StepNumber) {
            if (& $Verify) {
                Write-SetupStepHeader -StepNumber $StepNumber -TotalSteps $TotalSteps -Title $Title
                Write-SetupSuccess "$Title - already completed, skipping"
                return [pscustomobject]@{ Success = $true; Skipped = $true; Attempts = 0 }
            }
            Write-SetupWarning "$Title - marked complete but verification failed; re-running"
        }
    }

    Write-SetupStepHeader -StepNumber $StepNumber -TotalSteps $TotalSteps -Title $Title
    Update-StepState -StepNumber $StepNumber -StepName $Name -Status 'running'

    for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {
        Write-SetupInfo "Attempt $attempt of $MaxRetries..."
        Write-SetupLog "Step $StepNumber ($Name) attempt $attempt"

        try {
            $actionResult = & $Action
            if ($actionResult -eq $false) {
                throw "Action returned false for step $Name"
            }

            Start-Sleep -Milliseconds 500

            $verified = & $Verify
            if ($verified) {
                Update-StepState -StepNumber $StepNumber -StepName $Name -Status 'completed' -Attempts $attempt
                Write-SetupSuccess "$Title - done"
                Write-SetupLog "Step $StepNumber ($Name) completed on attempt $attempt"
                return [pscustomobject]@{ Success = $true; Skipped = $false; Attempts = $attempt }
            }

            throw "Verification failed for step $Name"
        }
        catch {
            $err = $_.Exception.Message
            Write-SetupLog "Step $StepNumber ($Name) attempt $attempt failed: $err" -Level ERROR
            Update-StepState -StepNumber $StepNumber -StepName $Name -Status 'running' -Attempts $attempt -ErrorMessage $err

            if ($attempt -lt $MaxRetries) {
                Write-SetupWarning "Attempt $attempt failed: $err"
                Write-SetupHint $FailureHint
                Write-SetupInfo 'Retrying...'
                Start-Sleep -Seconds 2
            }
            else {
                Update-StepState -StepNumber $StepNumber -StepName $Name -Status 'failed' -Attempts $attempt -ErrorMessage $err
                Write-SetupFailure "$Title - failed after $MaxRetries attempts"
                Write-SetupHint $FailureHint
                return [pscustomobject]@{ Success = $false; Skipped = $false; Attempts = $attempt; Error = $err }
            }
        }
    }
}