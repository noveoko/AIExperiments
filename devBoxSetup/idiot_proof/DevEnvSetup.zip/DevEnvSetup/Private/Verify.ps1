function Get-GitBashPath {
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Git\bin\bash.exe'),
        (Join-Path ${env:ProgramFiles} 'Git\bin\bash.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Git\bin\bash.exe')
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { return $c }
    }
    return $null
}

function Test-GitBashInstalled {
    $bash = Get-GitBashPath
    if (-not $bash) { return $false }
    try {
        $out = & $bash --version 2>&1
        return ($out -match 'bash')
    }
    catch { return $false }
}

function Test-WSLUbuntuInstalled {
    try {
        $list = wsl -l -v 2>&1 | Out-String
        return ($list -match 'Ubuntu')
    }
    catch { return $false }
}

function Test-PyenvWinInstalled {
    $pyenvRoot = Join-Path $env:USERPROFILE '.pyenv\pyenv-win'
    $pyenvBat = Join-Path $pyenvRoot 'bin\pyenv.bat'
    if (-not (Test-Path $pyenvBat)) { return $false }
    try {
        $out = & cmd /c "`"$pyenvBat`" --version" 2>&1
        return ($out -match 'pyenv')
    }
    catch { return $false }
}

function Get-PyenvPythonPath {
    $versions = Join-Path $env:USERPROFILE '.pyenv\pyenv-win\versions'
    $target = Join-Path $versions '3.10.11'
    $python = Join-Path $target 'python.exe'
    if (Test-Path $python) { return $python }
    return $null
}

function Test-Python311Installed {
    $python = Get-PyenvPythonPath
    if (-not $python) {
        $python = (Get-Command python -ErrorAction SilentlyContinue).Source
    }
    if (-not $python) { return $false }
    try {
        $out = & $python --version 2>&1
        return ($out -match '3\.10\.11')
    }
    catch { return $false }
}

function Get-ActivePython {
    $python = Get-PyenvPythonPath
    if ($python) { return $python }
    return (Get-Command python -ErrorAction SilentlyContinue).Source
}

function Test-PoetryInstalled {
    try {
        $out = poetry --version 2>&1
        return ($out -match 'Poetry')
    }
    catch { return $false }
}

function Test-PythonPackageInstalled {
    param([string]$PackageName)
    $python = Get-ActivePython
    if (-not $python) { return $false }
    $importName = $PackageName
    switch ($PackageName) {
        'pyyaml' { $importName = 'yaml' }
        'databricks-sdk' { $importName = 'databricks.sdk' }
        'databricks-cli' { return Test-DatabricksCliInstalled }
        'databricks-connect' { $importName = 'databricks.connect' }
    }
    try {
        & $python -c "import $importName" 2>&1 | Out-Null
        return ($LASTEXITCODE -eq 0)
    }
    catch { return $false }
}

function Test-DatabricksCliInstalled {
    try {
        $out = databricks --version 2>&1
        return ($out -match 'Databricks|databricks|Version')
    }
    catch { return $false }
}

function Test-DatabricksConnectInstalled {
    return Test-PythonPackageInstalled -PackageName 'databricks-connect'
}

function Get-DatabricksCfgPath {
    return Join-Path $env:USERPROFILE '.databrickscfg'
}

function Test-DatabricksCfgConfigured {
    $path = Get-DatabricksCfgPath
    if (-not (Test-Path $path)) { return $false }
    $content = Get-Content $path -Raw
    if ($content -notmatch '\[.+\]') { return $false }
    if ($content -notmatch 'host\s*=') { return $false }
    if ($content -notmatch 'token\s*=') { return $false }
    return $true
}

function Test-VSCodeInstalled {
    try {
        $out = code --version 2>&1
        return ($out -match '^\d+\.\d+')
    }
    catch { return $false }
}

function Test-VSCodeExtensionInstalled {
    param([string]$ExtensionId)
    try {
        $list = code --list-extensions 2>&1
        return ($list -contains $ExtensionId)
    }
    catch { return $false }
}

function Test-VSCodeExtensionsInstalled {
    $manifest = Get-Manifest
    $extensions = $manifest.artifacts | Where-Object { $_.category -eq 'vscode-extension' }
    foreach ($ext in $extensions) {
        if (-not (Test-VSCodeExtensionInstalled -ExtensionId $ext.extensionId)) {
            return $false
        }
    }
    return $true
}

function Invoke-ComponentVerification {
    param($Config)
    $manifest = Get-Manifest
    $results = @()

    foreach ($comp in $manifest.verifyComponents) {
        $status = 'FAIL'
        $detail = ''
        $action = ''

        switch ($comp.id) {
            'git-bash' {
                if (Test-GitBashInstalled) {
                    $status = 'OK'
                    $bash = Get-GitBashPath
                    $detail = (& $bash --version 2>&1 | Select-Object -First 1)
                }
                else { $action = 'Re-run step 2; verify Git installer in Artifactory generic repo' }
            }
            'wsl-ubuntu' {
                if (Test-WSLUbuntuInstalled) {
                    $status = 'OK'
                    $detail = 'Ubuntu distro registered in WSL'
                }
                else { $action = 'Re-run step 3; may require admin for WSL features' }
            }
            'pyenv-win' {
                if (Test-PyenvWinInstalled) {
                    $status = 'OK'
                    $detail = 'pyenv-win installed'
                }
                else { $action = 'Re-run step 4; verify pyenv-win.zip in Artifactory' }
            }
            'python-3.10.11' {
                if (Test-Python311Installed) {
                    $status = 'OK'
                    $python = Get-ActivePython
                    $detail = (& $python --version 2>&1)
                }
                else { $action = 'Re-run step 5; verify python-3.10.11-win32.zip mirror' }
            }
            'poetry' {
                if (Test-PoetryInstalled) {
                    $status = 'OK'
                    $detail = (poetry --version 2>&1)
                }
                else { $action = 'Re-run step 6; check PyPI mirror has poetry' }
            }
            'pytest' { $status, $detail, $action = Get-PackageVerifyResult 'pytest' 8 }
            'pyspark' { $status, $detail, $action = Get-PackageVerifyResult 'pyspark' 8 }
            'pandas' { $status, $detail, $action = Get-PackageVerifyResult 'pandas' 8 }
            'numpy' { $status, $detail, $action = Get-PackageVerifyResult 'numpy' 8 }
            'pyyaml' { $status, $detail, $action = Get-PackageVerifyResult 'pyyaml' 8 }
            'requests' { $status, $detail, $action = Get-PackageVerifyResult 'requests' 8 }
            'databricks-sdk' { $status, $detail, $action = Get-PackageVerifyResult 'databricks-sdk' 8 }
            'databricks-cli' {
                if (Test-DatabricksCliInstalled) {
                    $status = 'OK'
                    $detail = (databricks --version 2>&1 | Select-Object -First 1)
                }
                else { $action = 'Re-run step 9; check PyPI mirror has databricks-cli' }
            }
            'databricks-connect' {
                if (Test-DatabricksConnectInstalled) {
                    $status = 'OK'
                    $detail = 'databricks.connect importable'
                }
                else { $action = 'Re-run step 10; match databricks-connect version to cluster runtime' }
            }
            'databrickscfg' {
                if (Test-DatabricksCfgConfigured) {
                    $status = 'OK'
                    $detail = "~/.databrickscfg configured"
                }
                else { $action = 'Re-run step 11; provide host and token' }
            }
            'vscode' {
                if (Test-VSCodeInstalled) {
                    $status = 'OK'
                    $detail = (code --version 2>&1 | Select-Object -First 1)
                }
                else { $action = 'Re-run step 12; verify VS Code installer in Artifactory' }
            }
            'vscode-extensions' {
                if (Test-VSCodeExtensionsInstalled) {
                    $status = 'OK'
                    $detail = 'All required extensions installed'
                }
                else { $action = 'Re-run step 13; verify .vsix files in Artifactory' }
            }
        }

        $results += [pscustomobject]@{
            Id       = $comp.id
            Name     = $comp.name
            Step     = $comp.step
            Status   = $status
            Detail   = $detail
            Action   = $action
        }
    }

    return $results
}

function Get-PackageVerifyResult {
    param([string]$Package, [int]$Step)
    if (Test-PythonPackageInstalled -PackageName $Package) {
        return 'OK', "$Package installed", ''
    }
    return 'FAIL', '', "Re-run step $Step; check PyPI mirror has $Package"
}