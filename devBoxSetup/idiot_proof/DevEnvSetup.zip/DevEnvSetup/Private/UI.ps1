function Write-SetupBanner {
    Write-Host ''
    Write-Host '  ============================================================' -ForegroundColor Cyan
    Write-Host '       Dev Environment Setup  (Corporate Artifactory)        ' -ForegroundColor Cyan
    Write-Host '  ============================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '  This wizard will install and configure:' -ForegroundColor White
    Write-Host '    Python 3.10.11, pyenv-win, Git Bash, WSL Ubuntu, Poetry,' -ForegroundColor DarkGray
    Write-Host '    Databricks CLI/Connect, VS Code + extensions, and more.' -ForegroundColor DarkGray
    Write-Host ''
    Write-Host '  All downloads and packages route through Artifactory only.' -ForegroundColor Yellow
    Write-Host ''
}

function Write-SetupStepHeader {
    param(
        [int]$StepNumber,
        [int]$TotalSteps,
        [string]$Title
    )
    Write-Host ''
    Write-Host "  -- Step $StepNumber of $TotalSteps : $Title --" -ForegroundColor Cyan
    Write-Host ''
}

function Write-SetupSuccess {
    param([string]$Message)
    Write-Host "  [OK] $Message" -ForegroundColor Green
}

function Write-SetupFailure {
    param([string]$Message)
    Write-Host "  [FAIL] $Message" -ForegroundColor Red
}

function Write-SetupWarning {
    param([string]$Message)
    Write-Host "  ! $Message" -ForegroundColor Yellow
}

function Write-SetupInfo {
    param([string]$Message)
    Write-Host "  >> $Message" -ForegroundColor White
}

function Write-SetupHint {
    param([string]$Message)
    Write-Host "  HINT: $Message" -ForegroundColor DarkYellow
}

function Read-SetupPrompt {
    param(
        [string]$Message,
        [string]$Default = ''
    )
    if ($Default) {
        $input = Read-Host "  $Message (default: $Default)"
        if ([string]::IsNullOrWhiteSpace($input)) { return $Default }
        return $input.Trim()
    }
    return (Read-Host "  $Message").Trim()
}

function Read-SetupYesNo {
    param(
        [string]$Message,
        [string]$Default = 'Y'
    )
    $answer = Read-SetupPrompt -Message $Message -Default $Default
    return -not ($answer -match '^(n|no)$')
}

function Read-SetupSecurePrompt {
    param([string]$Message)
    $secure = Read-Host "  $Message" -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    }
}

function Read-SetupValidatedPrompt {
    param(
        [string]$Message,
        [scriptblock]$Validator,
        [string]$ErrorHint,
        [string]$Default = ''
    )
    while ($true) {
        $value = Read-SetupPrompt -Message $Message -Default $Default
        if (& $Validator $value) {
            return $value
        }
        Write-SetupWarning $ErrorHint
    }
}