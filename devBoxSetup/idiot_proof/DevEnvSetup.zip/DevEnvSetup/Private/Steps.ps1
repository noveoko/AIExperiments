function Invoke-StepPreflight {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    if ($PSVersionTable.PSVersion.Major -lt 5) {
        throw 'PowerShell 5.1 or later is required'
    }
    $policy = Get-ExecutionPolicy -Scope CurrentUser
    if ($policy -eq 'Restricted') {
        Write-SetupWarning 'Execution policy is Restricted for CurrentUser'
        if (Read-SetupYesNo -Message 'Set ExecutionPolicy to RemoteSigned (CurrentUser)? [Y/n]') {
            Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force
        }
    }
    $freeGb = (Get-PSDrive C).Free / 1GB
    if ($freeGb -lt 5) {
        Write-SetupWarning "Low disk space on C: ($([math]::Round($freeGb,1)) GB free). Recommend 5+ GB."
    }
    Write-SetupSuccess 'Preflight checks passed'
    return $true
}

function Test-StepPreflight {
    return ($PSVersionTable.PSVersion.Major -ge 5)
}

function Invoke-StepArtifactory {
    param($Manifest)
    $script:SetupConfig = Get-ArtifactoryConfig -Manifest $Manifest
    $script:SetupCredentials = Get-SetupCredentials
    if (-not $script:SetupConfig -or -not $script:SetupCredentials) {
        throw 'Artifactory configuration incomplete'
    }
    Set-ArtifactoryPipConfig -Config $script:SetupConfig -Credentials $script:SetupCredentials
    return $true
}

function Test-StepArtifactory {
    $cfg = Get-SetupConfig
    $cred = Get-SetupCredentials
    if (-not $cfg -or -not $cred) { return $false }
    $probe = Test-PypiRepo -RepoName $cfg.Repos.pypi -Config $cfg -Credentials $cred
    return $probe.Success
}

function Invoke-StepGitBash {
    param($Config, $Credentials, $Manifest)
    if (Test-GitBashInstalled) {
        Write-SetupInfo 'Git Bash already installed'
        return $true
    }
    $artifact = $Manifest.artifacts | Where-Object { $_.id -eq 'git-for-windows' }
    $url = Get-ArtifactDownloadUrl -Config $Config -Artifact $artifact
    $dest = Join-Path (Get-DownloadsDir) 'Git-Installer.exe'
    Invoke-ArtifactoryDownload -Url $url -Destination $dest -Config $Config -Credentials $Credentials
    Write-SetupInfo 'Installing Git for Windows (user scope)...'
    $proc = Start-Process -FilePath $dest -ArgumentList '/VERYSILENT', '/NORESTART', '/NOCANCEL', '/SP-', '/CLOSEAPPLICATIONS', '/CURRENTUSER', '/COMPONENTS=icons,ext\reg\shellhere,assoc,assoc_sh' -Wait -PassThru
    if ($proc.ExitCode -ne 0) {
        throw "Git installer exited with code $($proc.ExitCode)"
    }
    $gitBin = Join-Path $env:LOCALAPPDATA 'Programs\Git\bin'
    $gitCmd = Join-Path $env:LOCALAPPDATA 'Programs\Git\cmd'
    Add-ToUserPath @($gitBin, $gitCmd)
    return $true
}

function Invoke-StepWSLUbuntu {
    param($Config, $Credentials, $Manifest)
    if (Test-WSLUbuntuInstalled) {
        Write-SetupInfo 'WSL Ubuntu already configured'
        return $true
    }

    $wslStatus = wsl --status 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0 -or $wslStatus -match 'not installed|disabled') {
        Write-SetupWarning 'WSL may not be enabled'
        if (-not (Test-IsAdministrator)) {
            $elevated = Request-AdminElevation -Reason 'WSL feature installation requires Administrator privileges.'
            if (-not $elevated) {
                throw 'WSL not enabled and elevation declined'
            }
        }
        else {
            dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart | Out-Null
            dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart | Out-Null
            Write-SetupInfo 'WSL features enabled - a reboot may be required before import'
        }
    }

    $artifact = $Manifest.artifacts | Where-Object { $_.id -eq 'wsl-ubuntu-rootfs' }
    $url = Get-ArtifactDownloadUrl -Config $Config -Artifact $artifact
    $dest = Join-Path (Get-DownloadsDir) 'ubuntu-rootfs.tar.gz'
    Invoke-ArtifactoryDownload -Url $url -Destination $dest -Config $Config -Credentials $Credentials

    $wslDir = Join-Path $env:USERPROFILE 'wsl\ubuntu'
    if (-not (Test-Path $wslDir)) {
        New-Item -ItemType Directory -Path $wslDir -Force | Out-Null
    }

    Write-SetupInfo 'Importing Ubuntu into WSL (user location)...'
    wsl --import Ubuntu $wslDir $dest --version 2 2>&1 | ForEach-Object { Write-SetupLog $_ }
    if ($LASTEXITCODE -ne 0) {
        throw 'wsl --import failed - ensure WSL is enabled and reboot if needed'
    }
    wsl -d Ubuntu --exec bash -c "echo 'Ubuntu ready'" 2>&1 | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Invoke-StepPyenvWin {
    param($Config, $Credentials, $Manifest)
    if (Test-PyenvWinInstalled) {
        Write-SetupInfo 'pyenv-win already installed'
        return $true
    }

    $artifact = $Manifest.artifacts | Where-Object { $_.id -eq 'pyenv-win' }
    $url = Get-ArtifactDownloadUrl -Config $Config -Artifact $artifact
    $zipDest = Join-Path (Get-DownloadsDir) 'pyenv-win.zip'
    Invoke-ArtifactoryDownload -Url $url -Destination $zipDest -Config $Config -Credentials $Credentials

    $pyenvRoot = Join-Path $env:USERPROFILE '.pyenv\pyenv-win'
    if (Test-Path $pyenvRoot) {
        Remove-Item -Path $pyenvRoot -Recurse -Force
    }
    Expand-Archive -Path $zipDest -DestinationPath (Join-Path $env:USERPROFILE '.pyenv') -Force

    $nested = Get-ChildItem (Join-Path $env:USERPROFILE '.pyenv') -Directory | Where-Object { $_.Name -like 'pyenv-win*' } | Select-Object -First 1
    if ($nested -and $nested.FullName -ne $pyenvRoot) {
        if (Test-Path $pyenvRoot) { Remove-Item $pyenvRoot -Recurse -Force }
        Rename-Item $nested.FullName 'pyenv-win'
    }

    Set-UserEnvironmentVariable -Name 'PYENV' -Value (Join-Path $env:USERPROFILE '.pyenv\pyenv-win')
    Set-UserEnvironmentVariable -Name 'PYENV_ROOT' -Value (Join-Path $env:USERPROFILE '.pyenv\pyenv-win')
    Set-UserEnvironmentVariable -Name 'PYENV_HOME' -Value (Join-Path $env:USERPROFILE '.pyenv\pyenv-win')
    Add-ToUserPath @(
        (Join-Path $env:USERPROFILE '.pyenv\pyenv-win\bin'),
        (Join-Path $env:USERPROFILE '.pyenv\pyenv-win\shims')
    )
    return $true
}

function Invoke-StepPython {
    param($Config, $Credentials, $Manifest)
    if (Test-Python311Installed) {
        Write-SetupInfo 'Python 3.10.11 already installed'
        return $true
    }

    $artifact = $Manifest.artifacts | Where-Object { $_.id -eq 'python-3.10.11-win64' }
    $url = Get-ArtifactDownloadUrl -Config $Config -Artifact $artifact
    $zipName = Split-Path $artifact.probePath -Leaf
    $zipDest = Join-Path (Get-DownloadsDir) $zipName

    Invoke-ArtifactoryDownload -Url $url -Destination $zipDest -Config $Config -Credentials $Credentials

    $pyenvRoot = Join-Path $env:USERPROFILE '.pyenv\pyenv-win'
    $versionsDir = Join-Path $pyenvRoot 'versions\3.10.11'
    if (Test-Path $versionsDir) {
        Remove-Item $versionsDir -Recurse -Force
    }
    New-Item -ItemType Directory -Path $versionsDir -Force | Out-Null
    Expand-Archive -Path $zipDest -DestinationPath $versionsDir -Force

    $pyenvBat = Join-Path $pyenvRoot 'bin\pyenv.bat'
    & cmd /c "`"$pyenvBat`" rehash" 2>&1 | Out-Null
    & cmd /c "`"$pyenvBat`" global 3.10.11" 2>&1 | Out-Null

    $pythonExe = Join-Path $versionsDir 'python.exe'
    if (-not (Test-Path $pythonExe)) {
        $nested = Get-ChildItem $versionsDir -Recurse -Filter 'python.exe' | Select-Object -First 1
        if ($nested) {
            Copy-Item -Path (Join-Path $nested.Directory.FullName '*') -Destination $versionsDir -Recurse -Force
        }
    }
    return $true
}

function Invoke-StepPoetry {
    param($Config)
    if (Test-PoetryInstalled) { return $true }
    $python = Get-ActivePython
    if (-not $python) { throw 'Python not found - complete step 5 first' }
    Invoke-ArtifactoryPipInstall -Packages @('poetry') -Config $Config -PythonExe $python
    $poetryPath = Join-Path (Split-Path $python) 'Scripts'
    Add-ToUserPath @($poetryPath)
    return $true
}

function Invoke-StepPackageIndexConfig {
    param($Config)
    Set-ArtifactoryPipConfig -Config $Config -Credentials (Get-SetupCredentials)
    Set-ArtifactoryPoetryConfig -Config $Config
    return $true
}

function Test-StepPackageIndexConfig {
    $pipIni = Join-Path $env:APPDATA 'pip\pip.ini'
    if (-not (Test-Path $pipIni)) { return $false }
    $content = Get-Content $pipIni -Raw
    $cfg = Get-SetupConfig
    return ($content -match ([regex]::Escape($cfg.BaseUrl)) -or $content -match 'artifactory')
}

function Invoke-StepPythonPackages {
    param($Config, $Manifest)
    $python = Get-ActivePython
    if (-not $python) { throw 'Python not found' }

    $packages = @('pytest', 'pyspark', 'pandas', 'numpy', 'pyyaml', 'requests', 'databricks-sdk')
    Invoke-ArtifactoryPipInstall -Packages $packages -Config $Config -PythonExe $python

    $projectDir = Get-DevProjectDir
    Push-Location $projectDir
    try {
        if (-not (Test-Path 'pyproject.toml')) {
            if (Test-PoetryInstalled) {
                poetry init --name devenv-workspace --python="^3.10" --dependency pytest --dependency pyspark --dependency pandas --dependency numpy --dependency pyyaml --dependency requests --dependency databricks-sdk -n 2>&1 | Out-Null
            }
        }
    }
    finally {
        Pop-Location
    }
    return $true
}

function Test-StepPythonPackages {
    $packages = @('pytest', 'pyspark', 'pandas', 'numpy', 'pyyaml', 'requests', 'databricks-sdk')
    foreach ($p in $packages) {
        if (-not (Test-PythonPackageInstalled -PackageName $p)) { return $false }
    }
    return $true
}

function Invoke-StepDatabricksCli {
    param($Config)
    if (Test-DatabricksCliInstalled) { return $true }
    $python = Get-ActivePython
    Invoke-ArtifactoryPipInstall -Packages @('databricks-cli') -Config $Config -PythonExe $python
    Add-ToUserPath @((Join-Path (Split-Path $python) 'Scripts'))
    return $true
}

function Invoke-StepDatabricksConnect {
    param($Config)
    if (Test-DatabricksConnectInstalled) { return $true }
    $python = Get-ActivePython
    $version = Read-SetupPrompt -Message 'Databricks cluster runtime version (e.g. 13.3, 14.3)' -Default '13.3'
    $version = $version.Trim()
    Invoke-ArtifactoryPipInstall -Packages @("databricks-connect==$version.*") -Config $Config -PythonExe $python
    return $true
}

function Invoke-StepDatabricksCfg {
    param($Config, $Credentials)
    Write-SetupInfo 'Configuring ~/.databrickscfg'
    $profile = Read-SetupPrompt -Message 'Profile name' -Default 'DEFAULT'
    $dbHost = Read-SetupValidatedPrompt `
        -Message 'Databricks host URL (https://...)' `
        -Validator { param($v) $v -match '^https://' } `
        -ErrorHint 'Host must start with https://'
    $token = Read-SetupSecurePrompt -Message 'Databricks personal access token'

    $cfgPath = Get-DatabricksCfgPath
    $section = "[$profile]"
    $entry = @"
$section
host = $dbHost
token = $token

"@
    if (Test-Path $cfgPath) {
        $existing = Get-Content $cfgPath -Raw
        if ($existing -match "\[$([regex]::Escape($profile))\]") {
            Write-SetupWarning "Profile [$profile] exists - overwriting"
            $existing = $existing -replace "(?s)\[$([regex]::Escape($profile))\].*?(?=\[|\z)", ''
            $entry = $existing.TrimEnd() + "`n`n" + $entry
        }
        else {
            $entry = $existing.TrimEnd() + "`n`n" + $entry
        }
    }
    Set-Content -Path $cfgPath -Value $entry.TrimEnd() -Encoding UTF8

    $acl = Get-Acl $cfgPath
    $acl.SetAccessRuleProtection($true, $false)
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($env:USERNAME, 'FullControl', 'Allow')
    $acl.SetAccessRule($rule)
    Set-Acl -Path $cfgPath -AclObject $acl

    Write-SetupInfo 'Validating Databricks connection...'
    try {
        $headers = @{ Authorization = "Bearer $token" }
        $apiUrl = "$($dbHost.TrimEnd('/'))/api/2.0/clusters/list"
        $resp = Invoke-RestMethod -Uri $apiUrl -Headers $headers -Method Get -TimeoutSec 30 -ErrorAction Stop
        Write-SetupSuccess 'Databricks API connection verified'
    }
    catch {
        Write-SetupWarning "API validation failed: $($_.Exception.Message) - config saved, verify token/host manually"
    }
    return $true
}

function Invoke-StepVSCode {
    param($Config, $Credentials, $Manifest)
    if (Test-VSCodeInstalled) {
        Write-SetupInfo 'VS Code already installed'
        return $true
    }
    $artifact = $Manifest.artifacts | Where-Object { $_.id -eq 'vscode' }
    $url = Get-ArtifactDownloadUrl -Config $Config -Artifact $artifact
    $dest = Join-Path (Get-DownloadsDir) 'VSCodeUserSetup.exe'
    Invoke-ArtifactoryDownload -Url $url -Destination $dest -Config $Config -Credentials $Credentials
    Write-SetupInfo 'Installing VS Code (user scope)...'
    $proc = Start-Process -FilePath $dest -ArgumentList '/VERYSILENT', '/MERGETASKS=!runcode', '/CURRENTUSER' -Wait -PassThru
    if ($proc.ExitCode -ne 0) {
        throw "VS Code installer exited with code $($proc.ExitCode)"
    }
    $codeBin = Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\bin'
    Add-ToUserPath @($codeBin)
    return $true
}

function Invoke-StepVSCodeExtensions {
    param($Config, $Credentials, $Manifest)
    $extensions = $Manifest.artifacts | Where-Object { $_.category -eq 'vscode-extension' }
    foreach ($ext in $extensions) {
        if (Test-VSCodeExtensionInstalled -ExtensionId $ext.extensionId) {
            Write-SetupInfo "Extension $($ext.extensionId) already installed"
            continue
        }
        $url = Get-ArtifactDownloadUrl -Config $Config -Artifact $ext
        $dest = Join-Path (Get-DownloadsDir) (Split-Path $ext.probePath -Leaf)
        Invoke-ArtifactoryDownload -Url $url -Destination $dest -Config $Config -Credentials $Credentials
        Write-SetupInfo "Installing extension $($ext.extensionId)..."
        & code --install-extension $dest --force 2>&1 | ForEach-Object { Write-SetupLog $_ }
        if ($LASTEXITCODE -ne 0) {
            throw "Failed to install extension $($ext.extensionId)"
        }
    }
    return $true
}

function Invoke-StepFinalReport {
    param($Config)
    Write-SetupReport -Config $Config | Out-Null
    return $true
}