$script:DevEnvSetupRoot = Split-Path -Parent $PSScriptRoot
$script:SetupDataDir = Join-Path $env:USERPROFILE '.devenv-setup'
$script:ConfigPath = Join-Path $script:SetupDataDir 'config.json'
$script:CredentialsPath = Join-Path $script:SetupDataDir 'credentials.json'
$script:StatePath = Join-Path $script:SetupDataDir 'state.json'
$script:LogPath = Join-Path $script:SetupDataDir 'setup.log'
$script:ManifestPath = Join-Path $script:DevEnvSetupRoot 'Config\artifact-manifest.json'

function Initialize-SetupEnvironment {
    foreach ($dir in @($script:SetupDataDir, (Join-Path $script:SetupDataDir 'downloads'), (Join-Path $script:SetupDataDir 'cache'))) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
    }
    if (-not (Test-Path $script:LogPath)) {
        New-Item -ItemType File -Path $script:LogPath -Force | Out-Null
    }
}

function Write-SetupLog {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'DEBUG')]
        [string]$Level = 'INFO'
    )
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$timestamp] [$Level] $Message"
    Add-Content -Path $script:LogPath -Value $line -Encoding UTF8
}

function Get-Manifest {
    if (-not (Test-Path $script:ManifestPath)) {
        throw "Artifact manifest not found at $script:ManifestPath"
    }
    return Get-Content -Path $script:ManifestPath -Raw | ConvertFrom-Json
}

function Get-SetupConfig {
    if (Test-Path $script:ConfigPath) {
        return Get-Content -Path $script:ConfigPath -Raw | ConvertFrom-Json
    }
    return $null
}

function Save-SetupConfig {
    param([psobject]$Config)
    $Config | ConvertTo-Json -Depth 10 | Set-Content -Path $script:ConfigPath -Encoding UTF8
    Write-SetupLog "Saved setup config to $script:ConfigPath"
}

function Get-SetupCredentials {
    if (Test-Path $script:CredentialsPath) {
        $cred = Get-Content -Path $script:CredentialsPath -Raw | ConvertFrom-Json
        if ($cred.ApiKey) {
            $cred.ApiKey = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($cred.ApiKey))
        }
        if ($cred.Password) {
            $cred.Password = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($cred.Password))
        }
        return $cred
    }
    return $null
}

function Save-SetupCredentials {
    param(
        [string]$Username,
        [string]$ApiKey,
        [string]$Password
    )
    $payload = [ordered]@{}
    if ($Username) { $payload.Username = $Username }
    if ($ApiKey) {
        $payload.ApiKey = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($ApiKey))
    }
    if ($Password) {
        $payload.Password = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($Password))
    }
    $payload | ConvertTo-Json | Set-Content -Path $script:CredentialsPath -Encoding UTF8
    $acl = Get-Acl $script:CredentialsPath
    $acl.SetAccessRuleProtection($true, $false)
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
        $env:USERNAME, 'FullControl', 'Allow'
    )
    $acl.SetAccessRule($rule)
    Set-Acl -Path $script:CredentialsPath -AclObject $acl
    Write-SetupLog "Saved credentials (restricted ACL)"
}

function Get-SetupState {
    if (Test-Path $script:StatePath) {
        return Get-Content -Path $script:StatePath -Raw | ConvertFrom-Json
    }
    return [pscustomobject]@{
        steps    = @{}
        lastStep = -1
        started  = (Get-Date).ToString('o')
    }
}

function Save-SetupState {
    param([psobject]$State)
    if (-not $State.steps) {
        $State | Add-Member -NotePropertyName steps -NotePropertyValue @{} -Force
    }
    $State | ConvertTo-Json -Depth 10 | Set-Content -Path $script:StatePath -Encoding UTF8
}

function Update-StepState {
    param(
        [int]$StepNumber,
        [string]$StepName,
        [ValidateSet('pending', 'running', 'completed', 'failed', 'skipped')]
        [string]$Status,
        [int]$Attempts = 0,
        [string]$ErrorMessage = ''
    )
    $state = Get-SetupState
    if (-not $state.steps) {
        $state.steps = @{}
    }
    $stepKey = "step_$StepNumber"
    $state.steps | Add-Member -NotePropertyName $stepKey -NotePropertyValue ([pscustomobject]@{
        name         = $StepName
        status       = $Status
        attempts     = $Attempts
        errorMessage = $ErrorMessage
        updated      = (Get-Date).ToString('o')
    }) -Force
    if ($Status -eq 'completed') {
        $state.lastStep = [Math]::Max($state.lastStep, $StepNumber)
    }
    Save-SetupState -State $state
}

function Test-StepCompleted {
    param([int]$StepNumber)
    $state = Get-SetupState
    $stepKey = "step_$StepNumber"
    if ($state.steps.PSObject.Properties.Name -contains $stepKey) {
        return $state.steps.$stepKey.status -eq 'completed'
    }
    return $false
}

function Add-ToUserPath {
    param([string[]]$Paths)
    $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $segments = $userPath -split ';' | Where-Object { $_ }
    $changed = $false
    foreach ($p in $Paths) {
        if ($p -and ($segments -notcontains $p)) {
            $segments += $p
            $changed = $true
        }
    }
    if ($changed) {
        $newPath = ($segments -join ';')
        [Environment]::SetEnvironmentVariable('Path', $newPath, 'User')
        $env:Path = (($env:Path -split ';') + $Paths | Select-Object -Unique) -join ';'
        Write-SetupLog "Updated user PATH with: $($Paths -join ', ')"
    }
}

function Set-UserEnvironmentVariable {
    param(
        [string]$Name,
        [string]$Value
    )
    [Environment]::SetEnvironmentVariable($Name, $Value, 'User')
    Set-Item -Path "Env:$Name" -Value $Value
    Write-SetupLog "Set user env $Name"
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Request-AdminElevation {
    param([string]$Reason)
    Write-SetupInfo $Reason
    if (Test-IsAdministrator) {
        return $true
    }
    $answer = Read-SetupPrompt -Message 'Administrator privileges are required. Elevate now? [Y/n]' -Default 'Y'
    if ($answer -match '^(n|no)$') {
        return $false
    }
    $scriptPath = $MyInvocation.PSCommandPath
    if (-not $scriptPath) {
        $scriptPath = Join-Path $script:DevEnvSetupRoot '..\Setup-DevEnvironment.ps1'
    }
    Write-SetupInfo 'Requesting elevation...'
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$((Get-Item (Join-Path $script:DevEnvSetupRoot '..\Setup-DevEnvironment.ps1')).FullName)`" -Resume -Elevated"
    return $false
}

function Get-DownloadsDir {
    return Join-Path $script:SetupDataDir 'downloads'
}

function Get-CacheDir {
    return Join-Path $script:SetupDataDir 'cache'
}

function Get-DevProjectDir {
    $dir = Join-Path $env:USERPROFILE 'devenv-workspace'
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
    return $dir
}