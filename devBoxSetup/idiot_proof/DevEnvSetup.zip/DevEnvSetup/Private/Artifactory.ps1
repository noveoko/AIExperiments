function Get-ArtifactoryAuthHeader {
    param($Config, $Credentials)
    if ($Credentials.ApiKey) {
        if ($Credentials.Username) {
            $pair = "$($Credentials.Username):$($Credentials.ApiKey)"
            $bytes = [Text.Encoding]::ASCII.GetBytes($pair)
            return @{ Authorization = "Basic $([Convert]::ToBase64String($bytes))" }
        }
        return @{ 'X-JFrog-Art-Api' = $Credentials.ApiKey }
    }
    if ($Credentials.Username -and $Credentials.Password) {
        $pair = "$($Credentials.Username):$($Credentials.Password)"
        $bytes = [Text.Encoding]::ASCII.GetBytes($pair)
        return @{ Authorization = "Basic $([Convert]::ToBase64String($bytes))" }
    }
    return @{}
}

function Test-ArtifactoryEndpoint {
    param(
        [string]$Url,
        $Config,
        $Credentials,
        [switch]$HeadOnly
    )
    try {
        $headers = Get-ArtifactoryAuthHeader -Config $Config -Credentials $Credentials
        $params = @{
            Uri             = $Url
            Method          = if ($HeadOnly) { 'Head' } else { 'Get' }
            Headers         = $headers
            UseBasicParsing = $true
            TimeoutSec      = 30
            ErrorAction     = 'Stop'
        }
        if ($Config.Proxy) {
            $params.Proxy = $Config.Proxy
        }
        $response = Invoke-WebRequest @params
        return [pscustomobject]@{
            Success    = $true
            StatusCode = [int]$response.StatusCode
            Url        = $Url
        }
    }
    catch {
        $status = $null
        if ($_.Exception.Response) {
            $status = [int]$_.Exception.Response.StatusCode
        }
        return [pscustomobject]@{
            Success    = $false
            StatusCode = $status
            Url        = $Url
            Error      = $_.Exception.Message
        }
    }
}

function Assert-ArtifactoryUrl {
    param(
        [string]$Url,
        $Config
    )
    $base = $Config.BaseUrl.TrimEnd('/')
    if ($Url -notlike "$base*") {
        throw "URL blocked - must route through Artifactory ($base): $Url"
    }
}

function Get-ArtifactoryGenericUrl {
    param(
        $Config,
        [string]$ProbePath
    )
    $repo = $Config.Repos.generic
    $base = $Config.BaseUrl.TrimEnd('/')
    return "$base/artifactory/$repo/$ProbePath"
}

function Get-ArtifactoryExtensionUrl {
    param(
        $Config,
        [string]$ProbePath
    )
    $repo = $Config.Repos.vscodeExtension
    $base = $Config.BaseUrl.TrimEnd('/')
    return "$base/artifactory/$repo/$ProbePath"
}

function Get-ArtifactoryPypiUrl {
    param($Config)
    $repo = $Config.Repos.pypi
    $base = $Config.BaseUrl.TrimEnd('/')
    return "$base/api/pypi/$repo/simple"
}

function Invoke-ArtifactoryDownload {
    param(
        [string]$Url,
        [string]$Destination,
        $Config,
        $Credentials
    )
    Assert-ArtifactoryUrl -Url $Url -Config $Config
    $headers = Get-ArtifactoryAuthHeader -Config $Config -Credentials $Credentials
    $params = @{
        Uri             = $Url
        OutFile         = $Destination
        Headers         = $headers
        UseBasicParsing = $true
        TimeoutSec      = 600
        ErrorAction     = 'Stop'
    }
    if ($Config.Proxy) {
        $params.Proxy = $Config.Proxy
    }
    Write-SetupInfo "Downloading from Artifactory..."
    Write-SetupLog "Download: $Url -> $Destination"
    Invoke-WebRequest @params
    if (-not (Test-Path $Destination)) {
        throw "Download failed - file not found at $Destination"
    }
    return $Destination
}

function Test-PypiRepo {
    param(
        [string]$RepoName,
        $Config,
        $Credentials
    )
    $base = $Config.BaseUrl.TrimEnd('/')
    $url = "$base/api/pypi/$RepoName/simple/pip/"
    return Test-ArtifactoryEndpoint -Url $url -Config $Config -Credentials $Credentials
}

function Test-GenericRepo {
    param(
        [string]$RepoName,
        $Config,
        $Credentials
    )
    $base = $Config.BaseUrl.TrimEnd('/')
    $url = "$base/artifactory/$RepoName/"
    return Test-ArtifactoryEndpoint -Url $url -Config $Config -Credentials $Credentials
}

function Test-GenericArtifact {
    param(
        [string]$RepoName,
        [string]$ProbePath,
        $Config,
        $Credentials
    )
    $base = $Config.BaseUrl.TrimEnd('/')
    $url = "$base/artifactory/$RepoName/$ProbePath"
    return Test-ArtifactoryEndpoint -Url $url -Config $Config -Credentials $Credentials -HeadOnly
}

function Invoke-ArtifactoryProbe {
    param(
        $Config,
        $Credentials,
        $Manifest
    )
    $results = [ordered]@{
        pypi            = $null
        generic         = $null
        vscodeExtension = $null
        artifacts       = @()
    }

    foreach ($repoName in $Manifest.repoCategories.pypi.defaultRepoNames) {
        $probe = Test-PypiRepo -RepoName $repoName -Config $Config -Credentials $Credentials
        if ($probe.Success) {
            $results.pypi = $repoName
            break
        }
    }

    foreach ($repoName in $Manifest.repoCategories.generic.defaultRepoNames) {
        $probe = Test-GenericRepo -RepoName $repoName -Config $Config -Credentials $Credentials
        if ($probe.Success) {
            $results.generic = $repoName
            break
        }
    }

    foreach ($repoName in $Manifest.repoCategories.'vscode-extension'.defaultRepoNames) {
        $probe = Test-GenericRepo -RepoName $repoName -Config $Config -Credentials $Credentials
        if ($probe.Success) {
            $results.vscodeExtension = $repoName
            break
        }
    }

    if ($results.generic) {
        foreach ($artifact in $Manifest.artifacts) {
            if ($artifact.category -eq 'generic') {
                $probe = Test-GenericArtifact -RepoName $results.generic -ProbePath $artifact.probePath -Config $Config -Credentials $Credentials
                $results.artifacts += [pscustomobject]@{
                    Id      = $artifact.id
                    Found   = $probe.Success
                    Path    = $artifact.probePath
                    Repo    = $results.generic
                    Message = if ($probe.Success) { 'OK' } else { $probe.Error }
                }
            }
        }
    }

    if ($results.vscodeExtension) {
        foreach ($artifact in $Manifest.artifacts) {
            if ($artifact.category -eq 'vscode-extension') {
                $probe = Test-GenericArtifact -RepoName $results.vscodeExtension -ProbePath $artifact.probePath -Config $Config -Credentials $Credentials
                $results.artifacts += [pscustomobject]@{
                    Id      = $artifact.id
                    Found   = $probe.Success
                    Path    = $artifact.probePath
                    Repo    = $results.vscodeExtension
                    Message = if ($probe.Success) { 'OK' } else { $probe.Error }
                }
            }
        }
    }

    return [pscustomobject]$results
}

function Invoke-ArtifactoryWizard {
    param(
        $Manifest
    )
    Write-SetupInfo 'Artifactory configuration wizard'
    Write-Host ''
    Write-Host '  Enter your corporate Artifactory base URL.' -ForegroundColor DarkGray
    Write-Host '  Example: https://artifactory.corp.example.com' -ForegroundColor DarkGray
    Write-Host ''

    $baseUrl = Read-SetupValidatedPrompt `
        -Message 'Artifactory base URL' `
        -Validator { param($v) $v -match '^https?://' } `
        -ErrorHint 'URL must start with http:// or https://'

    $authMethod = Read-SetupPrompt -Message 'Auth method: [1] API key  [2] Username/password' -Default '1'

    $username = $null
    $apiKey = $null
    $password = $null

    if ($authMethod -eq '2') {
        $username = Read-SetupPrompt -Message 'Artifactory username'
        $password = Read-SetupSecurePrompt -Message 'Artifactory password'
    }
    else {
        $username = Read-SetupPrompt -Message 'Artifactory username (optional, press Enter to skip)' -Default ''
        $apiKey = Read-SetupSecurePrompt -Message 'Artifactory API key'
    }

    $proxy = Read-SetupPrompt -Message 'HTTP proxy URL (optional, press Enter to skip)' -Default ''

    $cred = [pscustomobject]@{
        Username = if ($username) { $username } else { $null }
        ApiKey   = $apiKey
        Password = $password
    }
    Save-SetupCredentials -Username $cred.Username -ApiKey $cred.ApiKey -Password $cred.Password

    $config = [pscustomobject]@{
        BaseUrl = $baseUrl.TrimEnd('/')
        Proxy   = if ($proxy) { $proxy } else { $null }
        Repos   = [pscustomobject]@{
            pypi            = $null
            generic         = $null
            vscodeExtension = $null
        }
        ArtifactOverrides = @{}
    }

    Write-SetupInfo 'Probing Artifactory repositories...'
    $probe = Invoke-ArtifactoryProbe -Config $config -Credentials $cred -Manifest $Manifest

    if ($probe.pypi) {
        Write-SetupSuccess "PyPI repo found: $($probe.pypi)"
        $config.Repos.pypi = $probe.pypi
    }
    else {
        Write-SetupWarning 'PyPI repo not auto-detected'
        $config.Repos.pypi = Read-SetupPrompt -Message 'Enter PyPI repository name'
    }

    if ($probe.generic) {
        Write-SetupSuccess "Generic repo found: $($probe.generic)"
        $config.Repos.generic = $probe.generic
    }
    else {
        Write-SetupWarning 'Generic repo not auto-detected'
        $config.Repos.generic = Read-SetupPrompt -Message 'Enter generic repository name (installers/archives)'
    }

    if ($probe.vscodeExtension) {
        Write-SetupSuccess "VS Code extension repo found: $($probe.vscodeExtension)"
        $config.Repos.vscodeExtension = $probe.vscodeExtension
    }
    else {
        Write-SetupWarning 'VS Code extension repo not auto-detected'
        $defaultExt = $config.Repos.generic
        $config.Repos.vscodeExtension = Read-SetupPrompt -Message 'Enter VS Code extension repository name' -Default $defaultExt
    }

    Write-Host ''
    Write-SetupInfo 'Checking required artifacts in Artifactory...'
    $missing = @()
    foreach ($artifact in $Manifest.artifacts) {
        $repo = if ($artifact.category -eq 'vscode-extension') { $config.Repos.vscodeExtension } else { $config.Repos.generic }
        $probeResult = Test-GenericArtifact -RepoName $repo -ProbePath $artifact.probePath -Config $config -Credentials $cred
        if ($probeResult.Success) {
            Write-SetupSuccess "$($artifact.name) - found"
        }
        else {
            Write-SetupWarning "$($artifact.name) - missing at $repo/$($artifact.probePath)"
            $missing += $artifact
        }
    }

    if ($missing.Count -gt 0) {
        Write-Host ''
        Write-SetupWarning 'Some artifacts are missing. Mirror them to Artifactory, or provide path overrides.'
        Write-Host ''
        Write-Host '  Expected paths under generic/extension repos:' -ForegroundColor DarkGray
        foreach ($m in $Manifest.artifacts) {
            Write-Host "    [$($m.category)] $($m.probePath)  - $($m.name)" -ForegroundColor DarkGray
        }
        Write-Host ''

        if (Read-SetupYesNo -Message 'Provide custom path overrides for missing artifacts now? [Y/n]' -Default 'N') {
            foreach ($m in $missing) {
                $override = Read-SetupPrompt -Message "Override path for $($m.name) (Enter to skip)" -Default ''
                if ($override) {
                    $config.ArtifactOverrides | Add-Member -NotePropertyName $m.id -NotePropertyValue $override -Force
                }
            }
        }
        else {
            Write-SetupHint 'Upload missing files to Artifactory, then re-run with -Resume'
        }
    }

    $pypiProbe = Test-PypiRepo -RepoName $config.Repos.pypi -Config $config -Credentials $cred
    if (-not $pypiProbe.Success) {
        Write-SetupWarning "PyPI repo '$($config.Repos.pypi)' not reachable - verify permissions"
    }
    else {
        Write-SetupSuccess "PyPI index reachable: $(Get-ArtifactoryPypiUrl -Config $config)"
    }

    Save-SetupConfig -Config $config
    return $config
}

function Get-ArtifactoryConfig {
    param($Manifest)
    $existing = Get-SetupConfig
    $cred = Get-SetupCredentials

    if ($existing -and $cred) {
        Write-SetupInfo "Using saved Artifactory config: $($existing.BaseUrl)"
        if (Read-SetupYesNo -Message 'Reconfigure Artifactory? [y/N]' -Default 'N') {
            return Invoke-ArtifactoryWizard -Manifest $Manifest
        }
        return $existing
    }

    return Invoke-ArtifactoryWizard -Manifest $Manifest
}

function Set-ArtifactoryPipConfig {
    param($Config, $Credentials)
    $indexUrl = Get-ArtifactoryPypiUrl -Config $Config
    $pipDir = Join-Path $env:APPDATA 'pip'
    if (-not (Test-Path $pipDir)) {
        New-Item -ItemType Directory -Path $pipDir -Force | Out-Null
    }
    $pipIni = Join-Path $pipDir 'pip.ini'
    $trustedHost = ([uri]$Config.BaseUrl).Host
    @"
[global]
index-url = $indexUrl
no-index = false
trusted-host = $trustedHost

[install]
trusted-host = $trustedHost
"@ | Set-Content -Path $pipIni -Encoding UTF8

    $env:PIP_INDEX_URL = $indexUrl
    $env:PIP_TRUSTED_HOST = $trustedHost
    Write-SetupLog "Configured pip.ini with Artifactory index"
}

function Set-ArtifactoryPoetryConfig {
    param($Config)
    $indexUrl = Get-ArtifactoryPypiUrl -Config $Config
    $poetryConfig = Join-Path $env:APPDATA 'pypoetry'
    if (-not (Test-Path $poetryConfig)) {
        New-Item -ItemType Directory -Path $poetryConfig -Force | Out-Null
    }
    $configToml = Join-Path $poetryConfig 'config.toml'
    @"
[repositories.artifactory]
url = "$indexUrl"

[virtualenvs]
in-project = true
"@ | Set-Content -Path $configToml -Encoding UTF8
    Write-SetupLog "Configured poetry config.toml with Artifactory"
}

function Invoke-ArtifactoryPipInstall {
    param(
        [string[]]$Packages,
        $Config,
        [string]$PythonExe = 'python'
    )
    $indexUrl = Get-ArtifactoryPypiUrl -Config $Config
    Assert-ArtifactoryUrl -Url $indexUrl -Config $Config
    $trustedHost = ([uri]$Config.BaseUrl).Host
    $args = @(
        '-m', 'pip', 'install',
        '--index-url', $indexUrl,
        '--trusted-host', $trustedHost,
        '--no-cache-dir'
    ) + $Packages

    Write-SetupLog "pip install: $($Packages -join ', ')"
    $output = & $PythonExe @args 2>&1
    $output | ForEach-Object { Write-SetupLog $_ }
    if ($LASTEXITCODE -ne 0) {
        throw "pip install failed: $($output -join "`n")"
    }
}

function Get-ArtifactDownloadUrl {
    param(
        $Config,
        $Artifact
    )
    if ($Config.ArtifactOverrides -and $Config.ArtifactOverrides.PSObject.Properties.Name -contains $Artifact.id) {
        $override = $Config.ArtifactOverrides.$($Artifact.id)
        if ($override -match '^https?://') {
            return $override
        }
        $repo = if ($Artifact.category -eq 'vscode-extension') { $Config.Repos.vscodeExtension } else { $Config.Repos.generic }
        $base = $Config.BaseUrl.TrimEnd('/')
        return "$base/artifactory/$repo/$override"
    }

    if ($Artifact.category -eq 'vscode-extension') {
        return Get-ArtifactoryExtensionUrl -Config $Config -ProbePath $Artifact.probePath
    }
    return Get-ArtifactoryGenericUrl -Config $Config -ProbePath $Artifact.probePath
}